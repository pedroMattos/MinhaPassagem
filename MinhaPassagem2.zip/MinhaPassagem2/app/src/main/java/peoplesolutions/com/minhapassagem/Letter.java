package peoplesolutions.com.minhapassagem;

public class Letter {
    private double letterSpacings;

    public double getLetterSpacings() {
        return letterSpacings;
    }

    public void setLetterSpacings(double letterSpacing) {
        this.letterSpacings = letterSpacing;
    }
}
